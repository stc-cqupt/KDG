import numpy as np
import matplotlib.pyplot as plt
import cv2
import torch
import time
import os

def visualize_pose_heatmaps_bchw(heatmaps, original_image=None, save_path=None, alpha=0.5):
    """
    可视化 [B, K, H, W] 的姿态估计热图，将所有人的所有关节点热图叠加在一张图上，
    并可选叠加在原图上。

    Args:
        heatmaps (torch.Tensor or np.ndarray): [B, K, H, W]
        original_image (np.ndarray): [H, W, 3]，原图，可选
        save_path (str): 可选，保存路径（含文件名）
        alpha (float): 热图与原图的叠加比例，默认 0.5
    """
    if isinstance(heatmaps, torch.Tensor):
        heatmaps = heatmaps.detach().cpu().numpy()

    B, K, H, W = heatmaps.shape
    combined_heatmap = np.zeros((H, W), dtype=np.float32)

    for b in range(B):
        for k in range(K):
            combined_heatmap += heatmaps[b, k]

    combined_heatmap -= combined_heatmap.min()
    if combined_heatmap.max() > 0:
        combined_heatmap /= combined_heatmap.max()

    heatmap_img = (combined_heatmap * 255).astype(np.uint8)
    heatmap_color = cv2.applyColorMap(heatmap_img, cv2.COLORMAP_JET)  # BGR

    # 原图处理与叠加
    if original_image is not None:
        if isinstance(original_image, torch.Tensor):
            original_image = original_image.detach().cpu().numpy()
        if original_image.dtype != np.uint8:
            original_image = (np.clip(original_image, 0, 1) * 255).astype(np.uint8)

        # Resize 原图至热图尺寸
        original_image = cv2.resize(original_image, (W, H))
        if original_image.shape[-1] != 3:
            raise ValueError("original_image must be of shape [H, W, 3]")

        overlay_img = cv2.addWeighted(original_image, 1 - alpha, heatmap_color, alpha, 0)
        display_img = cv2.cvtColor(overlay_img, cv2.COLOR_BGR2RGB)
    else:
        display_img = cv2.cvtColor(heatmap_color, cv2.COLOR_BGR2RGB)

    # 显示或保存
    plt.figure(figsize=(6, 6))
    plt.imshow(display_img)
    plt.title('Pose Heatmap Overlay' if original_image is not None else 'Combined Pose Heatmap')
    plt.axis('off')

    # if save_path is None:
    #     timestamp = time.strftime("%Y%m%d_%H%M%S")
    #     save_path = os.path.join("..", f"pose_heatmap_{timestamp}.png")

    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.show()