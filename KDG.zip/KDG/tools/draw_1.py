import torch
import torchvision.transforms.functional as TF
from PIL import Image, ImageDraw

def Visualization(image, points_set, radius, dataset, save_path=None):
    if dataset == "crowdpose":
        skeleton = [[0, 2], [1, 3], [2, 4], [3, 5], [6, 8], [8, 10], [7, 9], [9, 11], [12, 13], [0, 13], [1, 13], [6, 13],
                    [7, 13]]
        color = ["white", "white", "purple", "purple", "green", "green", "blue", "blue", "yellow", "yellow", "black",
                 "black", "red", "orange"]
    else:
        skeleton = [[0, 1], [0, 2], [1, 3], [2, 4], [3, 5], [4, 6], [5, 6], [5, 7], [5, 11], [6, 8], [6, 12], [7, 9],
                    [8, 10], [11, 12], [11, 13], [12, 14], [13, 15], [14, 16]]
        color = ["brown", "white", "white", "purple", "purple", "green", "green", "blue", "blue", "yellow", "yellow",
                 "black", "black", "red", "red", "orange", "orange"]
    color_1 = ["white", "red", "orange", "purple", "green"]

    draw = ImageDraw.Draw(image)
    n = 0
    for points in points_set:
        i = 0
        for line in skeleton:
            if points[line[0]][0] == -1 or points[line[1]][0] == -1:
                continue
            x_0 = points[line[0]][0]
            y_0 = points[line[0]][1]
            x_1 = points[line[1]][0]
            y_1 = points[line[1]][1]
            if n > 4:
                n = 0
            draw.line([(x_0, y_0), (x_1, y_1)], fill=color_1[n], width=2)
        for point in points:
            x, y, score = point
            x0 = x - radius
            y0 = y - radius
            x1 = x + radius
            y1 = y + radius
            draw.ellipse([(x0, y0), (x1, y1)], fill=color[i])
            i += 1
        n += 1

    tensor_image = TF.to_tensor(image)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tensor_image = tensor_image.to(device)
    result_image = TF.to_pil_image(tensor_image.cpu())

    # ✅ 保存图像（如果提供了路径）
    if save_path:
        result_image.save(save_path)

    return result_image

def Grouping(original_list):
    new_list = []
    group_size = 3

    for i in range(0, len(original_list), group_size):
        group = original_list[i:i + group_size]
        new_list.append(group)
    return new_list