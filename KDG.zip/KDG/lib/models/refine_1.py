import torch
from torch import nn
import torch.nn.functional as F
from collections import defaultdict
import math
import torchvision.ops as ops

BN_MOMENTUM = 0.1

def _sigmoid(x):
  y = torch.clamp(x.sigmoid_(), min=1e-4, max=1-1e-4)
  return y

HEAD_OFFSET_dict = {"NUM_BLOCKS": 2, "NUM_CHANNELS_PERKPT": 1, "DILATION_RATE": 1, "NUM_CHANNELS_OUT": 1, "FINAL_CONV_KERNEL": 1}

class AdaptBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, outplanes, stride=1,
                 downsample=None, dilation=1, deformable_groups=1):
        super(AdaptBlock, self).__init__()
        regular_matrix = torch.tensor([[-1, -1, -1, 0, 0, 0, 1, 1, 1], \
                                       [-1, 0, 1, -1, 0, 1, -1, 0, 1]])
        self.register_buffer('regular_matrix', regular_matrix.float())
        self.downsample = downsample
        self.transform_matrix_conv = nn.Conv2d(inplanes, 4, 3, 1, 1, bias=True)
        self.translation_conv = nn.Conv2d(inplanes, 2, 3, 1, 1, bias=True)
        self.adapt_conv = ops.DeformConv2d(inplanes, outplanes, kernel_size=3, stride=stride, \
                                           padding=dilation, dilation=dilation, bias=False, groups=deformable_groups)
        self.bn = nn.BatchNorm2d(outplanes, momentum=BN_MOMENTUM)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        residual = x

        N, _, H, W = x.shape
        transform_matrix = self.transform_matrix_conv(x)
        transform_matrix = transform_matrix.permute(0, 2, 3, 1).reshape((N * H * W, 2, 2))
        offset = torch.matmul(transform_matrix, self.regular_matrix)
        offset = offset - self.regular_matrix
        offset = offset.transpose(1, 2).reshape((N, H, W, 18)).permute(0, 3, 1, 2)

        translation = self.translation_conv(x)
        offset[:, 0::2, :, :] += translation[:, 0:1, :, :]
        offset[:, 1::2, :, :] += translation[:, 1:2, :, :]

        out = self.adapt_conv(x, offset)
        out = self.bn(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out

class REFINE(nn.Module):
    def __init__(self, cfg):
        super(REFINE, self).__init__()
        self.out_channels = 1
        self.num_joints = cfg.DATASET.NUM_KEYPOINTS + 1
        config_offset = HEAD_OFFSET_dict
        self.offset_prekpt = config_offset['NUM_CHANNELS_PERKPT']
        #offset_channels = self.num_joints * self.offset_prekpt
        #self.transition_offset = self._make_transition_for_head(
            #self.out_channels, offset_channels)
        self.offset_feature_layers, self.offset_final_layer = \
            self._make_separete_regression_head(config_offset)

    def _make_separete_regression_head(self, layer_config):#添加模块
        offset_feature_layers = []
        offset_final_layer = []

        for _ in range(self.num_joints):
            feature_conv = self._make_layer(
                AdaptBlock,
                layer_config['NUM_CHANNELS_PERKPT'],
                layer_config['NUM_CHANNELS_PERKPT'],
                layer_config['NUM_BLOCKS'],
                dilation=layer_config['DILATION_RATE']
            )
            offset_feature_layers.append(feature_conv)

            offset_conv = nn.Conv2d(
                in_channels=layer_config['NUM_CHANNELS_PERKPT'],
                out_channels=layer_config['NUM_CHANNELS_OUT'],
                kernel_size=layer_config['FINAL_CONV_KERNEL'],
                stride=1,
                padding=1 if layer_config['FINAL_CONV_KERNEL'] == 3 else 0
            )
            offset_final_layer.append(offset_conv)

        return nn.ModuleList(offset_feature_layers), nn.ModuleList(offset_final_layer)

    def _make_layer(
            self, block, inplanes, planes, blocks, stride=1, dilation=1):
        downsample = None
        if stride != 1 or inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion, momentum=BN_MOMENTUM),
            )

        layers = []
        layers.append(block(inplanes, planes,
                stride, downsample, dilation=dilation))
        inplanes = planes * block.expansion
        for _ in range(1, blocks):
            layers.append(block(inplanes, planes, dilation=dilation))

        return nn.Sequential(*layers)
    '''
    def _make_transition_for_head(self, inplanes, outplanes):
        transition_layer = [
            nn.Conv2d(inplanes, outplanes, 1, 1, 0, bias=False),
            nn.BatchNorm2d(outplanes),
            nn.ReLU(True)
        ]
        return nn.Sequential(*transition_layer)
    '''

    def forward(self, center_heatmap):
        final_offset = []
        for j in range(self.num_joints):
            final_offset.append(
                self.offset_final_layer[j](
                    self.offset_feature_layers[j](
                        center_heatmap[:, j*self.offset_prekpt:(j+1)*self.offset_prekpt]))) #对图像在通道上依据关节数进行分割
        center_heatmap = torch.cat(final_offset, dim=1)
        return center_heatmap






