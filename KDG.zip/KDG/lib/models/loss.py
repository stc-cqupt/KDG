import torch
from torch import nn
import torch.nn.functional as F

class FocalLoss(nn.Module):
    def __init__(self, alpha=2, beta=4):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.beta = beta

    def forward(self, pred, gt, mask=None):
        ''' Modified focal loss. Exactly the same as CornerNet.
            Runs faster and costs a little bit more memory
            Arguments:
              pred (batch x c x h x w)
              gt_regr (batch x c x h x w)
        '''
        pos_inds = gt.eq(1).float()
        neg_inds = gt.lt(1).float()

        if mask is not None:
            pos_inds = pos_inds * mask
            neg_inds = neg_inds * mask

        neg_weights = torch.pow(1 - gt, self.beta)

        loss = 0

        pos_loss = torch.log(pred) * torch.pow(1 - pred, self.alpha) * pos_inds
        neg_loss = torch.log(1 - pred) * torch.pow(pred, self.alpha) * neg_weights * neg_inds

        num_pos = pos_inds.float().sum()
        pos_loss = pos_loss.sum()
        neg_loss = neg_loss.sum()

        if num_pos == 0:
            loss = loss - neg_loss
        else:
            loss = loss - (pos_loss + neg_loss) / num_pos
        return loss

class ContrastiveLoss(nn.Module):
    def __init__(self, temperature=0.05):
        super(ContrastiveLoss, self).__init__()
        self.temp = temperature

    def forward(self, features):
        n = features.size(0)
        features_norm = F.normalize(features, dim=1)
        logits = features_norm.mm(features_norm.t()) / self.temp
        targets = torch.arange(n, dtype=torch.long).cuda()

        loss = F.cross_entropy(logits, targets, reduction='sum')
        return loss

class COSLoss(nn.Module):
    def __init__(self):
        super(COSLoss, self).__init__()
        # self.kl_loss = nn.KLDivLoss(reduction="sum")
        self.cos_loss = torch.nn.CosineSimilarity(dim=-1, eps=1e-07)

    def forward(self, y_true, y_pred):

        loss = 1 - torch.mean(self.cos_loss(y_pred, y_true))
        A = torch.all(y_pred == 0)
        print(A)
        return loss

    def _sigmoid(self, x):
        y = torch.clamp(x.sigmoid_(), min=1e-6, max=1 - 1e-6)
        return y

class rough_loss(nn.Module):
    def __init__(self):
        super(rough_loss, self).__init__()
        self.body_loss = ContrastiveLoss()
        self.head_list = [0, 1, 2, 3, 4]
        self.left_arm_list = [5, 7, 9]
        self.right_arm_list = [6, 8, 10]
        self.lef_leg_list = [11, 13, 15]
        self.right_leg_list = [12, 14, 16]
    def forward(self, input):
        _ = input.size(0)
        loss_list = []
        for n in range(_):
            head_f = input[n][self.head_list]
            left_arm_f = input[n][self.left_arm_list]
            right_arm_f = input[n][self.right_arm_list]
            lef_leg_f = input[n][self.lef_leg_list]
            right_leg_f = input[n][self.right_leg_list]
            for a in range(len(self.head_list)):
                for b in range(len(self.left_arm_list)):
                    for c in range(len(self.right_arm_list)):
                        for d in range(len(self.lef_leg_list)):
                            for e in range(len(self.right_leg_list)):
                                feature = torch.cat([head_f[a].unsqueeze(0), left_arm_f[b].unsqueeze(0),
                                                     right_arm_f[c].unsqueeze(0), lef_leg_f[d].unsqueeze(0),
                                                     right_leg_f[e].unsqueeze(0)], dim=0)
                                loss_body = self.body_loss(feature)
                                loss_list.append(loss_body)

        loss = sum(loss_list)/len(loss_list)
        return loss

class ContrastiveLoss_1(nn.Module):
    def __init__(self, temperature=0.05):
        super(ContrastiveLoss_1, self).__init__()
        self.temp = temperature
        self.cross_loss = nn.CrossEntropyLoss()

    def forward(self, features):
        b, c, n = features.size()
        features_norm = F.normalize(features, dim=1)
        logits = features_norm @ (features_norm.permute(0, 2, 1)) / self.temp
        targets = torch.arange(c, dtype=torch.long).unsqueeze(0).expand([b, -1]).cuda()
        loss = self.cross_loss(logits, targets)
        return loss

def main():

    # 创建一个大小为（8，14，128，128）的随机张量
    tensor = torch.randn(14, 17, 128).cuda()
    criterion = nn.SmoothL1Loss()
    h = rough_loss()
    h(tensor)

if __name__ == '__main__':
    main()
