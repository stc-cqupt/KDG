import torch
from torch import nn

def _sigmoid(x):
  y = torch.clamp(x.sigmoid_(), min=1e-4, max=1-1e-4)
  return y
class PRM(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(PRM, self).__init__()
        self.conv3X3 = nn.Conv2d(in_channels, out_channels, kernel_size=(3, 3), padding=1)
        self.middleconv1 = nn.Conv2d(in_channels, in_channels, kernel_size=(1, 1), padding=0)
        self.middleconv2 = nn.Conv2d(in_channels, in_channels, kernel_size=(1, 1), padding=0)
        self.bottomconv1 = nn.Conv2d(in_channels, out_channels, kernel_size=(1, 1), padding=0)
        self.DW = DepthwiseSeparableConv(in_channels, out_channels)
        self.GP = nn.AdaptiveAvgPool2d(1)

    def forward(self, feat):
        #top
        feat_top = self.conv3X3(feat)

        #middle
        vector_middle = self.GP(feat_top)
        vector_middle = self.middleconv1(vector_middle)
        vector_middle = _sigmoid(self.middleconv2(vector_middle))
        feat_middle = feat_top * vector_middle

        #bottom
        bottle_map = self.bottomconv1(feat_top)
        bottle_map = _sigmoid(self.DW(bottle_map))
        feat_middle = bottle_map * feat_middle

        feat_refine = feat_top + feat_middle

        return feat_refine

class DepthwiseSeparableConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DepthwiseSeparableConv, self).__init__()
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size=9, padding=4, groups=in_channels)
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x

def main():

    # 创建一个大小为（8，14，128，128）的随机张量
    tensor = torch.randn(8, 14, 128, 128)
    BLOCK74411 = PRM(14, 14)
    x = BLOCK74411(tensor)
    print(x)

if __name__ == '__main__':
    main()
