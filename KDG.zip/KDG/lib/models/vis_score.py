import torch
from torch import nn
import torch.nn.functional as F

class VIS(nn.Module):
    def __init__(self):
        super(VIS, self).__init__()

    def forward(self, instance_heatmaps, instances):
        instance_scores = instances['instance_score']
        num_people, num_keypoints, h, w = instance_heatmaps.size()
        center_pool = F.avg_pool2d(instance_heatmaps, self.center_pool_kernel, 1, (self.center_pool_kernel - 1) // 2)
        instance_heatmaps = (instance_heatmaps + center_pool) / 2.0
        nms_instance_heatmaps = instance_heatmaps.view(num_people, num_keypoints, -1)
        vals, inds = torch.max(nms_instance_heatmaps, dim=2)
        vals = vals * instance_scores.unsqueeze(1)
        return vals