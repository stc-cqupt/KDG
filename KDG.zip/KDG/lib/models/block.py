import torch
from torch import nn
import torch.nn.functional as F
from collections import defaultdict
import math

class HighResolutionContextBlock(nn.Module):
    expansion = 1

    def __init__(
            self,
            dim,
            mlp_ratio=4,
            num_kernels=1,
            drop_path=0.0,
            act_layer=nn.GELU,
            #conv_cfg=None,
            #norm_cfg=dict(type="BN"),
            with_cp=False
    ):
        super(HighResolutionContextBlock, self).__init__()
        self.with_cp = with_cp

        self.dlp = DynamicLocalPerception(
            dim,
            num_kernels=num_kernels,
            act_layer=act_layer,
            #conv_cfg=conv_cfg,
            #norm_cfg=norm_cfg
        )

        self.norm1 = nn.BatchNorm2d(dim)
        self.mlp1 = GlobalFFN(
            dim,
            act_layer=act_layer,
            #conv_cfg=conv_cfg,
            #norm_cfg=norm_cfg
        )

        self.norm2 = nn.BatchNorm2d(dim)
        hidden_dim = int(dim * mlp_ratio)
        self.mlp2 = DynamicFFN(
            in_features=dim,
            hidden_features=hidden_dim,
            out_features=dim,
            num_kernels=num_kernels,
            act_layer=act_layer,
            #conv_cfg=conv_cfg,
            #norm_cfg=norm_cfg
        )

        self.drop_path = nn.Dropout(drop_path) if drop_path > 0.0 else nn.Identity()

        layer_scale_init_value = 1e-2
        self.layer_scale_1 = nn.Parameter(layer_scale_init_value * torch.ones(dim), requires_grad=True)
        self.layer_scale_2 = nn.Parameter(layer_scale_init_value * torch.ones(dim), requires_grad=True)
        self.layer_scale_3 = nn.Parameter(layer_scale_init_value * torch.ones(dim), requires_grad=True)

    def forward(self, x):

        # DynamicLocalPerception
        x = x + self.drop_path(self.layer_scale_1.unsqueeze(-1).unsqueeze(-1).unsqueeze(0) * self.dlp(x))

        # GlobalFFN
        x = x + self.drop_path(self.layer_scale_2.unsqueeze(-1).unsqueeze(-1).unsqueeze(0) * self.mlp1(self.norm1(x)))

        # DynamicFFN
        x = x + self.drop_path(self.layer_scale_3.unsqueeze(-1).unsqueeze(-1).unsqueeze(0) * self.mlp2(self.norm2(x)))

        return x

class GlobalFFN(nn.Module):
    def __init__(
            self,
            dim,
            act_layer=nn.GELU,
            #conv_cfg=None,
            #norm_cfg=dict(type="BN"),
            with_cp=False
    ):
        super().__init__()
        self.with_cp = with_cp

        self.proj1 = nn.Conv2d(
            dim,
            dim,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=False
        )
        self.norm1 = nn.BatchNorm2d(dim)
        self.act = act_layer()

        self.spatial_gate = GlobalSpatialAttention(
            dim,
            #conv_cfg=conv_cfg,
            #norm_cfg=norm_cfg
        )

        self.proj2 = nn.Conv2d(
            #conv_cfg,
            dim,
            dim,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=False
        )
        self.norm2 = nn.BatchNorm2d(dim)

    def forward(self, x):

        shortcut = x.clone()

        x = self.proj1(x)
        x = self.norm1(x)
        x = self.act(x)

        x = self.spatial_gate(x)

        x = self.proj2(x)
        x = self.norm2(x)

        x = x + shortcut

        return x


class DynamicFFN(nn.Module):
    def __init__(
            self,
            in_features,
            hidden_features=None,
            out_features=None,
            num_kernels=1,
            act_layer=nn.GELU,
            #conv_cfg=None,
            #norm_cfg=dict(type="BN"),
            with_cp=False
    ):
        super().__init__()
        self.with_cp = with_cp

        out_features = out_features or in_features
        hidden_features = hidden_features or in_features

        self.proj1 = DConv(
            in_features,
            hidden_features,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=False,
            num_kernels=num_kernels,
            act_layer=act_layer,
            #conv_cfg=conv_cfg,
            #norm_cfg=norm_cfg
        )
        #self.norm1 = build_norm_layer(norm_cfg, hidden_features)[1]
        self.norm1 = nn.BatchNorm2d(hidden_features)
        self.dw = DConv(
            hidden_features,
            hidden_features,
            kernel_size=3,
            stride=1,
            padding=1,
            groups=hidden_features,
            bias=False,
            num_kernels=num_kernels,
            act_layer=act_layer,
            #conv_cfg=conv_cfg,
            #norm_cfg=norm_cfg
        )
        #self.norm2 = build_norm_layer(norm_cfg, hidden_features)[1]
        self.norm2 = nn.BatchNorm2d(hidden_features)
        self.act = act_layer()

        self.proj2 = DConv(
            hidden_features,
            out_features,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=False,
            num_kernels=num_kernels,
            act_layer=act_layer,
            #conv_cfg=conv_cfg,
            #norm_cfg=norm_cfg
        )
        #self.norm3 = build_norm_layer(norm_cfg, out_features)[1]
        self.norm3 = nn.BatchNorm2d(out_features)

    def forward(self, x):
        x = self.proj1(x)
        x = self.norm1(x)

        x = self.dw(x)
        x = self.norm2(x)
        x = self.act(x)

        x = self.proj2(x)
        x = self.norm3(x)

        return x


class DConv(nn.Module):
    def __init__(
            self,
            in_channels,
            out_channels,
            kernel_size=1,
            stride=1,
            padding=0,
            dilation=1,
            groups=1,
            bias=True,
            num_kernels=1,
            act_layer=nn.GELU,
            #conv_cfg=None,
            #norm_cfg=dict(type="BN")
    ):
        super().__init__()
        if num_kernels > 1:
            self.conv = DynamicKernelAggregation(
                in_channels,
                out_channels,
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                groups=groups,
                bias=bias,
                num_kernels=num_kernels,
                act_layer=act_layer,
                #conv_cfg=conv_cfg,
                #norm_cfg=norm_cfg
            )
        else:
            self.conv = nn.Conv2d(
                in_channels,
                out_channels,
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                groups=groups,
                bias=bias
            )

    def forward(self, x):
        x = self.conv(x)
        return x

class DynamicKernelAggregation(nn.Module):
    def __init__(
            self,
            in_channels,
            out_channels,
            kernel_size,
            stride=1,
            padding=0,
            dilation=1,
            groups=1,
            bias=True,
            num_kernels=4,
            act_layer=nn.GELU,
            #conv_cfg=None,
            #norm_cfg=dict(type="BN")
    ):
        super().__init__()
        assert in_channels % groups == 0

        self.attention = KernelAttention(
            in_channels,
            num_kernels=num_kernels,
            act_layer=act_layer,
            #conv_cfg=conv_cfg,
            #norm_cfg=norm_cfg
        )

        self.aggregation = KernelAggregation(
            in_channels,
            out_channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
            dilation=dilation,
            groups=groups,
            bias=bias,
            num_kernels=num_kernels
        )

    def forward(self, x):
        attention = x

        attention = self.attention(attention)
        x = self.aggregation(x, attention)

        return x

class KernelAttention(nn.Module):
    def __init__(
            self,
            channels,
            reduction=4,
            num_kernels=4,
            init_weight=True,
            act_layer=nn.GELU,
            #conv_cfg=None,
            #norm_cfg=dict(type="BN")
    ):
        super().__init__()
        if channels != 3:
            mid_channels = channels // reduction
        else:
            mid_channels = num_kernels

        self.avg_pool = nn.AdaptiveAvgPool2d(1)

        self.conv1 = nn.Conv2d(
            channels,
            mid_channels,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=False
        )
        self.norm = nn.BatchNorm2d(mid_channels)
        self.act = act_layer()

        self.conv2 = nn.Conv2d(
            mid_channels,
            num_kernels,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=True
        )
        self.sigmoid = nn.Sigmoid()

        if init_weight:
            self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            if isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        x = self.avg_pool(x)

        x = self.conv1(x)
        x = self.norm(x)
        x = self.act(x)

        x = self.conv2(x).view(x.shape[0], -1)
        x = self.sigmoid(x)

        return x

class KernelAggregation(nn.Module):

    def __init__(
            self,
            in_channels,
            out_channels,
            kernel_size,
            stride,
            padding,
            dilation,
            groups,
            bias,
            num_kernels,
            init_weight=True
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.bias = bias
        self.num_kernels = num_kernels

        self.weight = nn.Parameter(
            torch.randn(num_kernels, out_channels, in_channels // groups, kernel_size, kernel_size),
            requires_grad=True
        )
        if bias:
            self.bias = nn.Parameter(
                torch.zeros(num_kernels, out_channels)
            )
        else:
            self.bias = None

        if init_weight:
            self._initialize_weights()

    def _initialize_weights(self):
        for i in range(self.num_kernels):
            nn.init.kaiming_uniform_(self.weight[i])

    def forward(self, x, attention):
        batch_size, in_channels, height, width = x.size()

        x = x.contiguous().view(1, batch_size * self.in_channels, height, width)

        weight = self.weight.contiguous().view(self.num_kernels, -1)
        weight = torch.mm(attention, weight).contiguous().view(
            batch_size * self.out_channels,
            self.in_channels // self.groups,
            self.kernel_size,
            self.kernel_size
        )

        if self.bias is not None:
            bias = torch.mm(attention, self.bias).contiguous().view(-1)
            x = F.conv2d(
                x,
                weight=weight,
                bias=bias,
                stride=self.stride,
                padding=self.padding,
                dilation=self.dilation,
                groups=self.groups * batch_size
            )
        else:
            x = F.conv2d(
                x,
                weight=weight,
                bias=None,
                stride=self.stride,
                padding=self.padding,
                dilation=self.dilation,
                groups=self.groups * batch_size
            )

        x = x.contiguous().view(batch_size, self.out_channels, x.shape[-2], x.shape[-1])

        return x

class GlobalSpatialAttention(nn.Module):
    def __init__(
            self,
            dim,
            #conv_cfg=None,
            #norm_cfg=dict(type="BN")
    ):
        super().__init__()
        # depth-wise convolution
        self.dw = nn.Conv2d(
            dim,
            dim,
            kernel_size=5,
            stride=1,
            padding=2,
            groups=dim,
            bias=False
        )
        self.norm1 = nn.BatchNorm2d(dim)

        # depth-wise dilation convolution
        self.dwd = nn.Conv2d(
            dim,
            dim,
            kernel_size=7,
            stride=1,
            padding=9,
            dilation=3,
            groups=dim,
            bias=False
        )
        self.norm2 = nn.BatchNorm2d(dim)

        # channel convolution
        self.pw = nn.Conv2d(
            #conv_cfg,
            dim,
            dim,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=False
        )
        self.norm3 = nn.BatchNorm2d(dim)

    def forward(self, x):
        attn = x.clone()

        attn = self.norm1(self.dw(attn))
        attn = self.norm2(self.dwd(attn))
        attn = self.norm3(self.pw(attn))

        return x * attn

class DynamicLocalPerception(nn.Module):
    def __init__(
            self,
            dim,
            num_kernels=1,
            act_layer=nn.GELU,
            #conv_cfg=None,
            #norm_cfg=dict(type="BN"),
            with_cp=False
    ):
        super().__init__()
        self.with_cp = with_cp

        self.dw3x3 = DConv(
            dim,
            dim,
            kernel_size=3,
            stride=1,
            padding=1,
            groups=dim,
            bias=False,
            num_kernels=num_kernels,
            act_layer=act_layer,
            #conv_cfg=conv_cfg,
            #norm_cfg=norm_cfg
        )
        self.norm = nn.BatchNorm2d(dim)
        self.act = act_layer()

    def forward(self, x):
        x = self.act(self.norm(self.dw3x3(x)))
        return x

class run_gffn(nn.Module):
    def __init__(
            self,
            dim,
            act_layer=nn.GELU,
            #conv_cfg=None,
            #norm_cfg=dict(type="BN"),
            with_cp=False
    ):
        super().__init__()
        self.gffn = GlobalFFN(dim, act_layer, with_cp)
    def forward(self, x):
        x = self.gffn(x)
        return x

class run_dffn(nn.Module):
    def __init__(
            self,
            in_features,
            hidden_features=None,
            out_features=None,
            num_kernels=1,
            act_layer=nn.GELU,
            #conv_cfg=None,
            #norm_cfg=dict(type="BN"),
            with_cp=False
    ):
        super().__init__()
        self.dffn = DynamicFFN(in_features, hidden_features, out_features, num_kernels, act_layer, with_cp)
    def forward(self, x):
        x = self.dffn(x)
        return x

class BLOCK_123(nn.Module):
    def __init__(
            self,
            dim,
            mlp_ratio=4,
            num_kernels=1,
            drop_path=0.0,
            act_layer=nn.GELU,
            # conv_cfg=None,
            # norm_cfg=dict(type="BN"),
            with_cp=False
    ):
        super().__init__()
        self.highblock = HighResolutionContextBlock(dim, mlp_ratio, num_kernels, drop_path, act_layer, with_cp)
    def forward(self, x):
        x = self.highblock(x)
        return x

class FPN(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(FPN, self).__init__()
        self.adaptive_avg_poolX2 = nn.AvgPool2d(kernel_size=2)
        self.conv3layer = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(3, 3), padding=1),
            nn.ReLU()
        )
        #self.highblock = HighResolutionContextBlock(dim=in_channels)
        self.highblock = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(1, 1), padding=0),
            nn.ReLU()
        )

    def forward(self, feature):
        feature_downX2 = self.adaptive_avg_poolX2(feature)
        feature_downX4 = self.adaptive_avg_poolX2(feature_downX2)
        feature_downX8 = self.adaptive_avg_poolX2(feature_downX4)
        feature_downX16 = self.adaptive_avg_poolX2(feature_downX8)
        feature_upX16 = self.highblock(feature_downX16)
        feature_upX8 = self.highblock(feature_downX8) + F.interpolate(feature_upX16, scale_factor=2, mode='nearest')
        feature_upX4 = self.highblock(feature_downX4) + F.interpolate(feature_upX8, scale_factor=2, mode='nearest')
        feature_upX2 = self.highblock(feature_downX2) + F.interpolate(feature_upX4, scale_factor=2, mode='nearest')
        P_X8 = self.conv3layer(feature_upX8)
        P_X4 = self.conv3layer(feature_upX4)
        P_X2 = self.conv3layer(feature_upX2)
        P_X8 = F.interpolate(P_X8, scale_factor=4, mode='nearest')
        P_X4 = F.interpolate(P_X4, scale_factor=2, mode='nearest')
        P = P_X8 + P_X4 + P_X2
        P = F.interpolate(P, scale_factor=2, mode='nearest')
        return P

def main():

    # 创建一个大小为（8，14，128，128）的随机张量
    tensor = torch.randn(8, 14, 128, 128)
    BLOCK74411 = FPN(14, 14)
    x = BLOCK74411(tensor)

    print(x)

if __name__ == '__main__':
    main()